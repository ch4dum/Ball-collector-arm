#include "robot_arm1/cpp_header.hpp"

#include <iostream>

int main() {
    std::cout << "Hello World!\n";
    return 0;
}
