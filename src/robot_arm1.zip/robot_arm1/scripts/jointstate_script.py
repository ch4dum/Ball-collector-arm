#!/usr/bin/python3

import rclpy
from rclpy.node import Node
from sensor_msgs.msg import JointState
from std_msgs.msg import Float64MultiArray
from geometry_msgs.msg import Twist
from std_msgs.msg import Int16, Bool
from math import pi
import numpy as np

class JointStateNode(Node):
    def __init__(self):
        super().__init__('jointstate_script_node')

        self.velo_pub = self.create_publisher(Float64MultiArray, "/velocity_controllers/commands",10)
        self.joint_sub = self.create_subscription(JointState, "/joint_states",self.joint_state_callback, 10)
        # self.joint_pub = self.create_publisher(JointState, "/joint_states", 10)
        self.capture_pub = self.create_publisher(Bool, "/capture", 10)  # Publisher for /capture
        self.cmd_sub = self.create_subscription(Twist, "cmd_vel", self.cmd_vel_callback, 10)
        self.mode_sub = self.create_subscription(Int16, "/change_mode", self.change_mode_callback, 10)
        
        self.dt = 0.01  
        self.q = [0.0, 0.0, 0.0, 0.0, 0.0]  
        self.cmd = 0.0  
        self.name = ["joint1", "joint2", "joint3", "joint4", "left_gear_joint", "left_finger_joint", "right_gear_joint", "right_finger_joint"]  
        self.velo = [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0]
        self.pos = []
        self.mode = 0
        self.total_modes = 10
        self.step = 0
        self.count_step = 0
        self.set_step_joint2 = [0, 0.376, 0.752, 1.096, 1.2]
        self.joint_order = [
            "joint1",
            "joint2",
            "joint3",
            "joint4",
            "left_gear_joint",
            "left_finger_joint",
            "right_gear_joint",
            "right_finger_joint"
        ]
        
        self.path_points = [
            (0.9, 0.0), (1.25, 0.0),
            (1.25, 0.376), (0.9, 0.376),
            (0.9, 0.752), (1.25, 0.752),
            (1.25, 1.096), (0.9, 1.096)
        ]
        self.current_target_index = 0  # ชี้ไปยังจุดเป้าหมายปัจจุบัน
        self.pause_timer = 0.0
        self.moving_to_target = True
        self.y_pid = {"kp": 10.0, "ki": 0.0, "kd": 0.0, "prev_error": 0.0, "integral": 0.0}
        self.x_pid = {"kp": 5.0, "ki": 0.0, "kd": 0.0, "prev_error": 0.0, "integral": 0.0}

        # PID Parameters for joint1 and joint2
        self.joint1_pid = {"kp": 32.0, "ki": 0.0, "kd": 0.01, "prev_error": 0.0, "integral": 0.0}
        self.joint2_pid = {"kp": 32.0, "ki": 16.0, "kd": 4.0, "prev_error": 0.0, "integral": 0.0}
        #"kp": 80.0, "ki": 15.0, "kd": 30.0,
        # Joint limits
        self.limits = [
            (0.0, 2.3),         # Joint 1
            (0.0, 1.2),         # Joint 2
            (-1.570, 0.0),      # Joint 3
            (0.0, 0.300),       # Joint 4
            (-1, -0.4),     # left_gear_joint
            (-0.5,0.5),         # left_finger_joint
            (1,0.4),        # right_gear_joint
            (-0.5,0.5)          # right_finger_joint
        ]
        self.joint1_direction = 1
        self.joint1_at_limit = False
        self.home_completed = False
        self.pause_flag = False  # Flag to indicate if we are pausing
        self.pause_start_time = None  # Start time for the pause
        self.pause_duration = 0.25  # Pause duration in seconds

        self.create_timer(self.dt, self.sim_loop)
        startup_message = """
        ====================================================
                    🚀 JointStateNode has started! 🚀
        ====================================================
        Use the following command to change mode:
            ros2 topic pub /change_mode std_msgs/Int16 "data: N"

        Where N is:
        ---------- Teleop Mode  ----------
            1-8: Joint control
                1. joint1
                2. joint2
                3. joint3
                4. joint4
                5. left_gear_joint
                6. left_finger_joint
                7. right_gear_joint
                8. right_finger_joint

        ---------- Set Home Mode ----------
            9: Set home mode

        ---------- Taking Picture Mode ----------
            10: Taking picture (Auto mode)

        ====================================================
        """
        self.get_logger().info(startup_message)



    def joint_state_callback(self, msg):
        joint_position_map = {name: pos for name, pos in zip(msg.name, msg.position)}
        self.pos = [joint_position_map.get(joint, 0.0) for joint in self.joint_order]

    def cmd_vel_callback(self, msg: Twist):
        self.cmd = msg.linear.x

    def change_mode_callback(self, msg: Int16):
        if 1 <= msg.data <= self.total_modes:
            self.mode = msg.data
            self.get_logger().info(f"""
    ====================================================
                🔄 Mode changed to: {self.mode}
    ====================================================
    {"Teleop Mode: Control joints." if 1 <= self.mode <= 8 else 
    "Set Home Mode: Moving to home position." if self.mode == 9 else 
    "Taking Picture Mode: Auto-capture mode." if self.mode == 10 else ""}
    """)
        else:
            self.get_logger().warn(f"❗ Invalid mode: {msg.data}. Mode must be between 1 and {self.total_modes}.")

            
    def pid_control(self, target, current, pid_params):
        error = target - current
        pid_params["integral"] += error * self.dt
        derivative = (error - pid_params["prev_error"]) / self.dt
        output = (
            pid_params["kp"] * error +
            pid_params["ki"] * pid_params["integral"] +
            pid_params["kd"] * derivative
        )
        pid_params["prev_error"] = error
        return output

    def sim_loop(self):

        self.velo = [0.0] * len(self.velo)
        
        tolerance = 0.005

        if self.mode == 0:
            self.velo = [0.0] * len(self.velo)
        
        # SetHome
        if self.mode == 9:
            if abs(self.pos[4] - self.limits[4][0]) <= tolerance and abs(self.pos[6] - self.limits[6][0]) <= tolerance:
                self.velo[3] = -0.5
                if abs(self.pos[3] - self.limits[3][0]) <= tolerance:
                    self.velo[2] = 0.5
                    if abs(self.pos[2] - self.limits[2][1]) <= tolerance:
                        self.velo[1] = -0.5
                        if abs(self.pos[1] - self.limits[1][0]) <= tolerance:
                            self.velo[0] = -0.5
                            if abs(self.pos[0] - self.limits[0][0]) <= tolerance:
                                self.velo = [0.0] * len(self.velo)
                                self.get_logger().info("""
        ====================================================
                        ✅ Home position reached!
        ====================================================
        """)
                                self.mode = 0
                                return
            else:
                self.velo[4] = -0.5
                self.velo[6] = 0.5


        
        # Taking Picture
        if self.mode == 10:
            if self.moving_to_target:
                target_x, target_y = self.path_points[self.current_target_index]

                # PID Control
                pid_x = self.pid_control(target_x, self.pos[0], self.x_pid)
                self.velo[0] = np.clip(pid_x, -0.5, 0.5)

                pid_y = self.pid_control(target_y, self.pos[1], self.y_pid)
                self.velo[1] = np.clip(pid_y, -0.5, 0.5)

                # Check if reached target
                if abs(target_x - self.pos[0]) < 0.001 and abs(target_y - self.pos[1]) < 0.001:
                    self.velo[0] = 0.0
                    self.velo[1] = 0.0
                    self.pause_timer = 0.0
                    self.moving_to_target = False
                    self.get_logger().info(f"""
        ====================================================
            🎯 Reached target point: {self.path_points[self.current_target_index]}
        ====================================================
        """)
            else:
                self.pause_timer += self.dt
                if self.pause_timer >= 0.25:
                    self.current_target_index += 1
                    if self.current_target_index >= len(self.path_points):
                        self.current_target_index = 0
                        self.mode = 9
                        self.get_logger().info("""
        ====================================================
            📸 Path complete. Switching to Home Mode.
        ====================================================
        """)
                    else:
                        self.moving_to_target = True
                        self.get_logger().info(f"""
        ====================================================
            🚶 Moving to next point: {self.path_points[self.current_target_index]}
        ====================================================
        """)


        # Teleop
        else:
            for i in range(1, 9):
                if self.mode == i:
                    self.velo[i-1] = self.cmd

        msg = Float64MultiArray()
        msg.layout.dim = []         
        msg.layout.data_offset = 0
        msg.data = self.velo
        self.velo_pub.publish(msg)

        # # Publish to /capture based on pause_flag
        # capture_msg = Bool()
        # capture_msg.data = self.pause_flag
        # self.capture_pub.publish(capture_msg)

        # if self.pause_flag:
        #     # Check if the pause duration has passed
        #     if (self.get_clock().now().nanoseconds * 1e-9) - self.pause_start_time >= self.pause_duration:
        #         self.pause_flag = False  # End the pause
        #         self.get_logger().info("Pause complete. Resuming motion.")
        #     else:
        #         # Keep paused
        #         return

        # if self.mode == 6:
        #     # Joint1 PID Control
        #     joint1_target = self.q[0] + (self.joint1_direction * self.cmd * self.dt)
        #     joint1_control = self.pid_control(joint1_target, self.q[0], self.joint1_pid)
        #     self.q[0] += joint1_control * self.dt

        #     # Check for pause conditions
        #     if abs(self.q[0] - 0.9) < 1e-2 or abs(self.q[0] - 1.25) < 1e-2:
        #         self.pause_flag = True
        #         self.pause_start_time = self.get_clock().now().nanoseconds * 1e-9
        #         self.get_logger().info(f"Pausing motion at joint1 position: {self.q[0]:.2f}")
        #         return  # Skip further processing during pause

        #     # Joint2 Step Control with PID
        #     if self.step == 1:
        #         joint2_target = self.q[1] + self.cmd * self.dt
        #         joint2_control = self.pid_control(joint2_target, self.q[1], self.joint2_pid)
        #         self.q[1] += joint2_control * self.dt

        #         if joint2_target >= self.set_step_joint2[self.count_step]:
        #             self.step = 0
        #             if(self.count_step <len(self.set_step_joint2)):
        #                 self.count_step += 1
            
        #     # Check if joint1 reached limit
        #     if self.q[0] >= self.limits[0][1] or self.q[0] <= self.limits[0][0]:
        #         self.joint1_direction *= -1
        #         if not self.joint1_at_limit:
        #             if self.q[1] < self.limits[1][1]:
        #                 self.step = 1  # Enable joint2 movement
        #             else:
        #                 self.get_logger().info("Joint2 reached limit. Switching to Mode 7.")
        #                 self.mode = 7
        #         self.joint1_at_limit = True
        #     else:
        #         self.joint1_at_limit = False

        # elif self.mode == 7:
        #     # Reset to home position (smoothly)
        #     self.count_step = 0
        #     home_reached = True
        #     for i in [0, 1]:  # Joint1 and Joint2
        #         delta_home = (0.0 - self.q[i]) * 0.1
        #         self.q[i] += delta_home
        #         if abs(self.q[i]) > 1e-3:
        #             home_reached = False

        #     if home_reached:
        #         self.get_logger().info("Returned to home position. Operation completed.")
        #         self.mode = 0

        # # Apply joint limits
        # self.velo = [
        #     max(min(self.velo[i], self.limits[i][1]), self.limits[i][0])
        #     for i in range(len(self.velo))
        # ]

def main(args=None):
    rclpy.init(args=args)
    node = JointStateNode()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()